import modfunc

interface=modfunc.menu()